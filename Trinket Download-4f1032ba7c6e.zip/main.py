import turtle as trtl

painter = trtl.Turtle()



import tkinter as tk
import random

FPS = 100

# Colors
WHITE = "#FFFFFF"
RED = "#FF0000"
PALE = "#FFFFE0"
BLACK = "#000000"

root = tk.Tk()
root.title("Snowy Window with Kids")
# placemnet of picture
w = 250
h = 250

ws = root.winfo_screenwidth() 
hs = root.winfo_screenheight() 
# placemnet of picture
x = (ws-w-210)
y = (hs-2*h-25)

root.geometry('%dx%d+%d+%d' % (w, h, x, y))


canvas = tk.Canvas(root, width=w, height=h, bg=BLACK)
canvas.pack()

snowflakes = []

# Stick figure settings
kid1_pos = (100, 200)
kid2_pos = (200, 200)
ball_pos = [193, 200]
ball_direction = 1

# Function to create snowflakes
def create_snowflake():
    x = random.randint(0, w)
    y = random.randint(-20, h)
    snowflakes.append([x, y])

def update_scene():
    global ball_pos, ball_direction
    canvas.delete("all")

    # Draw kids
    canvas.create_oval(kid1_pos[0] - 20, kid1_pos[1] - 20, kid1_pos[0] + 20, kid1_pos[1] + 20, fill=PALE, outline="")
    canvas.create_oval(kid2_pos[0] - 20, kid2_pos[1] - 20, kid2_pos[0] + 20, kid2_pos[1] + 20, fill=PALE, outline="")

    # Draw ball
    canvas.create_oval(ball_pos[0] - 10, ball_pos[1] - 10, ball_pos[0] + 10, ball_pos[1] + 10, fill=RED, outline="")

    # Update ball position
    ball_pos[0] += ball_direction * 5
    if ball_pos[0] > 193 or ball_pos[0] < 100:
        ball_direction *= -1

    # Create snowflakes
    if random.randint(1, 5) == 1:
        create_snowflake()

    for snowflake in snowflakes:
        snowflake[1] += 1
        canvas.create_oval(snowflake[0] - 2, snowflake[1] - 2, snowflake[0] + 2, snowflake[1] + 2, fill=WHITE, outline="")

    snowflakes[:] = [s for s in snowflakes if s[1] < h]

    root.after(int(1000 / FPS), update_scene)

update_scene()

#time for presents!
#present 1
painter.fillcolor("blue")
painter.penup()
painter.goto(-90,-130)
painter.pendown()
painter.begin_fill()
painter.forward(100)
painter.left(90)
painter.forward(50)
painter.left(90)
painter.forward(100)
painter.left(90)
painter.forward(50)
painter.end_fill()
#ribbon
painter.fillcolor("red")
painter.right(180)
painter.goto(-50,-130)
painter.begin_fill()
painter.forward(50)
painter.right(90)
painter.forward(15)
painter.right(90)
painter.forward(50)
painter.right(90)
painter.forward(15)
painter.end_fill()
painter.right(180)

#present2
painter.fillcolor("pink")
painter.penup()
painter.goto(-90,-80)
painter.pendown()
painter.begin_fill()
painter.forward(50)
painter.left(90)
painter.forward(25)
painter.left(90)
painter.forward(50)
painter.left(90)
painter.forward(25)
painter.end_fill()
#ribbon
painter.fillcolor("purple")
painter.right(180)
painter.goto(-70,-80)
painter.begin_fill()
painter.forward(25)
painter.right(90)
painter.forward(15)
painter.right(90)
painter.forward(25)
painter.right(90)
painter.forward(15)
painter.end_fill()
painter.right(180)

#Time to make the tree
#treestump
painter.fillcolor("brown")
painter.penup()
painter.goto(-130,-130)
painter.right(270)
painter.pendown()
painter.begin_fill()
painter.forward(130)
painter.right(90)
painter.forward(30)
painter.right(90)
painter.forward(130)
painter.right(90)
painter.forward(30)
painter.end_fill()
painter.penup()

#time for tree leaves
#:(
painter.fillcolor("green")
painter.goto(-115, -50)
painter.pendown()
painter.begin_fill()
painter.forward(60)
painter.right(105)
painter.forward(200)
painter.goto(-115,143)
painter.left(213)
painter.forward(200)
painter.goto(-115,-50)
painter.end_fill()

import turtle

line_turtle = turtle.Turtle()


line_turtle.color("black")

line_turtle.penup()
line_turtle.goto(-200,-130)
line_turtle.pendown()
line_turtle.forward(400)

line_turtle.right(90)
#naveed's part
painter.speed(69420)
timer_running = True

def change_colors():
    global timer_running
    if timer_running:
        painter.fillcolor("chartreuse")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-100, 0)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("blue")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-130, 50)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("red")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-120, 100)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("yellow")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-150, -25)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("red")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-100, 0)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("chartreuse")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-130, 50)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("yellow")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-120, 100)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        painter.fillcolor("blue")
        painter.pencolor("black")
        painter.penup()
        painter.goto(-150, -25)
        painter.pendown()
        painter.begin_fill()
        painter.circle(5)
        painter.end_fill()

        wn.ontimer(change_colors, 1) 

def start_timer():
    global timer_running
    timer_running = True
    change_colors()

def stop_timer():
    global timer_running
    timer_running = False

wn = trtl.Screen()
painter = trtl.Turtle()

start_timer()


while True:
    request = input(str("Do you want to stop the flashing lights? (yes or no): "))
    if request == "yes":
        stop_timer()
    elif request == "no":
        start_timer()
    else:
        print("Invalid input. Please reply with 'yes' or 'no'.")
wn = turtle.Screen()

wn = trtl.Screen()

wn.mainloop()
